# Resolução de Problemas I - Trabalho III (Cat)

## Grupo

* André L. R. Estevam RA: 166348
* Caroline Lucas Calheirani RA: 168926
* Mayara Naomi Fustaino Ramos RA: 184517


